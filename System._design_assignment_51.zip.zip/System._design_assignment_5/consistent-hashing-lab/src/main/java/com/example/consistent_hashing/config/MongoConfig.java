package com.example.consistent_hashing.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Reads the initial MongoDB node URIs from application.properties and
 * exposes them as a simple Map bean. NodeManager uses this map to build
 * a MongoTemplate for each node at startup.
 *
 * mongodb4 is NOT included here on purpose: it is added later at runtime
 * through POST /nodes/add to demonstrate dynamic node addition.
 */
@Configuration
public class MongoConfig {

    @Value("${node.mongodb1.uri}")
    private String mongodb1Uri;

    @Value("${node.mongodb2.uri}")
    private String mongodb2Uri;

    @Value("${node.mongodb3.uri}")
    private String mongodb3Uri;

    @Bean
    public Map<String, String> initialNodeUris() {
        Map<String, String> uris = new LinkedHashMap<>();
        uris.put("mongodb1", mongodb1Uri);
        uris.put("mongodb2", mongodb2Uri);
        uris.put("mongodb3", mongodb3Uri);
        return uris;
    }
}
