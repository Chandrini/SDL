package com.example.consistent_hashing.service;

import com.example.consistent_hashing.hashing.ConsistentHashRing;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Keeps track of every active MongoDB storage node:
 * - its connection URI
 * - its own MongoTemplate
 * - its position on the consistent hash ring
 */
@Component
public class NodeManager {

    private final Map<String, String> nodeUris = new LinkedHashMap<>();
    private final Map<String, MongoTemplate> nodeTemplates = new LinkedHashMap<>();
    private final ConsistentHashRing ring = new ConsistentHashRing();

    public NodeManager(Map<String, String> initialNodeUris) {
        for (Map.Entry<String, String> entry : initialNodeUris.entrySet()) {
            registerNode(entry.getKey(), entry.getValue());
        }
    }

    public void registerNode(String name, String uri) {
        MongoTemplate template;
        try {
            template = new MongoTemplate(new SimpleMongoClientDatabaseFactory(uri));
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid MongoDB URI for node " + name + ": " + uri);
        }
        nodeUris.put(name, uri);
        nodeTemplates.put(name, template);
        ring.addNode(name);
    }

    public void unregisterNode(String name) {
        nodeUris.remove(name);
        nodeTemplates.remove(name);
        ring.removeNode(name);
    }

    public boolean nodeExists(String name) {
        return nodeUris.containsKey(name);
    }

    public MongoTemplate getTemplate(String name) {
        MongoTemplate template = nodeTemplates.get(name);
        if (template == null) {
            throw new IllegalArgumentException("Node not found: " + name);
        }
        return template;
    }

    public Set<String> getActiveNodeNames() {
        return nodeUris.keySet();
    }

    public int getActiveNodeCount() {
        return nodeUris.size();
    }

    public ConsistentHashRing getRing() {
        return ring;
    }
}
