package com.example.consistent_hashing.service;

import com.example.consistent_hashing.model.Student;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class StudentService {

    private final NodeManager nodeManager;

    public StudentService(NodeManager nodeManager) {
        this.nodeManager = nodeManager;
    }

    public String addStudent(Student student) {
        if (student.getId() == null || student.getId().isEmpty()) {
            throw new IllegalArgumentException("Student id is required");
        }
        String node = nodeManager.getRing().getNode(student.getId());
        MongoTemplate template = nodeManager.getTemplate(node);
        template.save(student);
        return node;
    }

    public Student getStudent(String id) {
        String node = nodeManager.getRing().getNode(id);
        MongoTemplate template = nodeManager.getTemplate(node);
        Student student = template.findById(id, Student.class);
        if (student == null) {
            throw new IllegalArgumentException("Student not found: " + id);
        }
        return student;
    }

    public List<Student> getAllStudents() {
        List<Student> all = new ArrayList<>();
        for (String node : nodeManager.getActiveNodeNames()) {
            all.addAll(nodeManager.getTemplate(node).findAll(Student.class));
        }
        return all;
    }

    public String getRouteNode(String id) {
        return nodeManager.getRing().getNode(id);
    }

    public Map<String, Long> getDistribution() {
        Map<String, Long> distribution = new LinkedHashMap<>();
        for (String node : nodeManager.getActiveNodeNames()) {
            long count = nodeManager.getTemplate(node).count(new Query(), Student.class);
            distribution.put(node, count);
        }
        return distribution;
    }

    /**
     * Adds a new node and migrates ONLY the student records whose owner
     * actually changes after the node joins the ring.
     */
    public Map<String, Object> addNodeAndMigrate(String name, String uri) {
        if (nodeManager.nodeExists(name)) {
            throw new IllegalArgumentException("Node already exists: " + name);
        }

        // Step 1: record every student's CURRENT owner before the ring changes.
        Map<String, String> studentOldNode = new LinkedHashMap<>();
        for (String node : nodeManager.getActiveNodeNames()) {
            for (Student s : nodeManager.getTemplate(node).findAll(Student.class)) {
                studentOldNode.put(s.getId(), node);
            }
        }

        // Step 2: add the new node to the ring (and create its MongoTemplate).
        nodeManager.registerNode(name, uri);

        // Step 3: for each student, compare old owner vs new owner and migrate only if different.
        int migratedCount = 0;
        for (Map.Entry<String, String> entry : studentOldNode.entrySet()) {
            String studentId = entry.getKey();
            String oldNode = entry.getValue();
            String newNode = nodeManager.getRing().getNode(studentId);

            if (!newNode.equals(oldNode)) {
                MongoTemplate oldTemplate = nodeManager.getTemplate(oldNode);
                MongoTemplate newTemplate = nodeManager.getTemplate(newNode);
                Student student = oldTemplate.findById(studentId, Student.class);
                if (student != null) {
                    newTemplate.save(student);
                    // BUG FIX: Delete the record from the old node to prevent duplication
                    oldTemplate.remove(student);
                    migratedCount++;
                }
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Node added successfully");
        result.put("newNode", name);
        result.put("migratedRecords", migratedCount);
        result.put("distribution", getDistribution());
        return result;
    }

    /**
     * Removes a node and redistributes ONLY the student records that were
     * physically stored on that node.
     */
    public Map<String, Object> removeNodeAndMigrate(String name) {
        if (!nodeManager.nodeExists(name)) {
            throw new IllegalArgumentException("Node not found: " + name);
        }
        if (nodeManager.getActiveNodeCount() <= 1) {
            throw new IllegalStateException("Cannot remove the last remaining node.");
        }

        // Step 1: read all records from the node being removed BEFORE touching anything else.
        MongoTemplate removedTemplate = nodeManager.getTemplate(name);
        List<Student> studentsToMigrate = removedTemplate.findAll(Student.class);

        // Step 2: remove the node from the hash ring only (templates/uris still intact).
        nodeManager.getRing().removeNode(name);

        // Step 3: recompute the new owner for each affected student using the NEW ring.
        int migratedCount = 0;
        for (Student student : studentsToMigrate) {
            String newNode = nodeManager.getRing().getNode(student.getId());
            MongoTemplate newTemplate = nodeManager.getTemplate(newNode);
            newTemplate.save(student);
            // BUG FIX: Delete the record from the old node to prevent duplication
            removedTemplate.remove(student);
            migratedCount++;
        }

        // Step 4: only now remove the node from the active node map entirely.
        nodeManager.unregisterNode(name);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message", "Node removed successfully");
        result.put("removedNode", name);
        result.put("migratedRecords", migratedCount);
        result.put("distribution", getDistribution());
        return result;
    }
}
