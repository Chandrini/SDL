package com.example.consistent_hashing.hashing;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeMap;

/**
 * Simple consistent hashing ring backed by a TreeMap.
 * Each physical node is represented by 100 virtual nodes
 * (nodeName-VN-0 ... nodeName-VN-99) spread across the ring.
 */
public class ConsistentHashRing {

    private static final int VIRTUAL_NODES = 100;

    private final TreeMap<Long, String> ring = new TreeMap<>();

    public void addNode(String nodeName) {
        for (int i = 0; i < VIRTUAL_NODES; i++) {
            String virtualNodeKey = nodeName + "-VN-" + i;
            long hash = hash(virtualNodeKey);
            ring.put(hash, nodeName);
        }
    }

    public void removeNode(String nodeName) {
        ring.entrySet().removeIf(entry -> entry.getValue().equals(nodeName));
    }

    public String getNode(String key) {
        if (ring.isEmpty()) {
            throw new IllegalStateException("Hash ring is empty. No nodes available.");
        }
        long hash = hash(key);
        Long targetKey = ring.ceilingKey(hash);
        if (targetKey == null) {
            // wrap around to the first node in the ring
            targetKey = ring.firstKey();
        }
        return ring.get(targetKey);
    }

    public Set<String> getNodes() {
        return new LinkedHashSet<>(ring.values());
    }

    public TreeMap<Long, String> getRing() {
        return ring;
    }

    public static long hash(String key) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(key.getBytes());
            ByteBuffer buffer = ByteBuffer.wrap(bytes);
            return buffer.getLong();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }
}
