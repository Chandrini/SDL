package com.example.autocomplete.trie;

import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
public class Trie {
    private final TrieNode root=new TrieNode();

    public void insert(String term,int frequency){
        TrieNode current=root;

        for(char ch:term.toLowerCase().toCharArray()){
            current.children.putIfAbsent(ch,new TrieNode());
            current=current.children.get(ch);
        }
        current.isEndOfWord=true;
        current.term=term;
        current.frequency=frequency;
    }
    private TrieNode findPrefixNode(String prefix){
        TrieNode current=root;

        for(char ch:prefix.toLowerCase().toCharArray()){
            if(!current.children.containsKey(ch)){
                return null;
            }
            current=current.children.get(ch);
        }
        return current;
    }
    private void collectWords(TrieNode node, List<TrieNode> results) {
        if (node.isEndOfWord) {
            results.add(node);
        }

        for (TrieNode child : node.children.values()) {
            collectWords(child, results);
        }
    }
    public List<TrieNode> search(String prefix, int k) {
        TrieNode prefixNode = findPrefixNode(prefix);

        if (prefixNode == null) {
            return new ArrayList<>();
        }

        List<TrieNode> results = new ArrayList<>();

        collectWords(prefixNode, results);

        results.sort(Comparator.comparingInt(
            (TrieNode node) -> node.frequency
        ).reversed());

        return results.stream()
                .limit(k)
                .toList();
    }
}

