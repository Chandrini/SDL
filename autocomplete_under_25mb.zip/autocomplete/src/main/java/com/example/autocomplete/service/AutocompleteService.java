package com.example.autocomplete.service;

import com.example.autocomplete.model.AutocompleteResponse;
import com.example.autocomplete.model.Suggestion;
import com.example.autocomplete.trie.Trie;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Service
public class AutocompleteService {

    private final Trie trie = new Trie();
    private final StringRedisTemplate redis;

    public AutocompleteService(StringRedisTemplate redis) {
        this.redis = redis;
        loadData();
    }

    private void loadData() {
        try {
            ClassPathResource file =
                    new ClassPathResource("search_terms.csv");

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            file.getInputStream(),
                            StandardCharsets.UTF_8));

            reader.readLine();

            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");

                String term = data[0].trim();
                int frequency = Integer.parseInt(data[1].trim());

                trie.insert(term, frequency);
            }

            reader.close();

        } catch (Exception e) {
            throw new RuntimeException("Could not load dataset");
        }
    }

    public AutocompleteResponse search(String prefix, int k) {

        String key = "autocomplete:" + prefix.toLowerCase() + ":" + k;

        // Check Redis
        String cached = redis.opsForValue().get(key);

        if (cached != null) {

            List<Suggestion> suggestions = new ArrayList<>();

            if (!cached.isEmpty()) {
                String[] items = cached.split("\\|");

                for (String item : items) {
                    String[] data = item.split("::");

                    suggestions.add(
                            new Suggestion(
                                    data[0],
                                    Integer.parseInt(data[1])
                            )
                    );
                }
            }

            return new AutocompleteResponse(
                    "REDIS",
                    prefix,
                    suggestions
            );
        }

        // Cache miss - search Trie
        List<Suggestion> suggestions =
                trie.search(prefix, k)
                        .stream()
                        .map(node -> new Suggestion(
                                node.getTerm(),
                                node.getFrequency()))
                        .toList();

        // Store result in Redis
        StringBuilder value = new StringBuilder();

        for (Suggestion suggestion : suggestions) {

            if (value.length() > 0) {
                value.append("|");
            }

            value.append(suggestion.getTerm())
                    .append("::")
                    .append(suggestion.getFrequency());
        }

        redis.opsForValue().set(key, value.toString());

        return new AutocompleteResponse(
                "TRIE",
                prefix,
                suggestions
        );
    }
}