package com.example.autocomplete.model;

public class SearchTerm {

    private String term;
    private int frequency;

    public SearchTerm(String term, int frequency) {
        this.term = term;
        this.frequency = frequency;
    }

    public String getTerm() {
        return term;
    }

    public int getFrequency() {
        return frequency;
    }
}