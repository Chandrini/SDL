package com.example.autocomplete.trie;

import java.util.HashMap;
import java.util.Map;

public class TrieNode {

    Map<Character, TrieNode> children = new HashMap<>();
    boolean isEndOfWord;
    String term;
    int frequency;

    public Map<Character, TrieNode> getChildren() {
        return children;
    }

    public boolean isEndOfWord() {
        return isEndOfWord;
    }

    public String getTerm() {
        return term;
    }

    public int getFrequency() {
        return frequency;
    }
}