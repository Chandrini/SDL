package com.example.autocomplete.model;

public class Suggestion {

    private String term;
    private int frequency;

    public Suggestion(String term, int frequency) {
        this.term = term;
        this.frequency = frequency;
    }

    public String getTerm() {
        return term;
    }

    public int getFrequency() {
        return frequency;
    }
}