package com.example.autocomplete.model;

import java.util.List;

public class AutocompleteResponse {

    private String source;
    private String prefix;
    private List<Suggestion> suggestions;

    public AutocompleteResponse(String source, String prefix,
                                List<Suggestion> suggestions) {
        this.source = source;
        this.prefix = prefix;
        this.suggestions = suggestions;
    }

    public String getSource() {
        return source;
    }

    public String getPrefix() {
        return prefix;
    }

    public List<Suggestion> getSuggestions() {
        return suggestions;
    }
}