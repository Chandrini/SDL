#!/bin/bash
# Run this on YOUR machine where JMeter is installed (not inside this sandbox,
# which has no internet access to download JMeter itself).
#
# Usage: ./run_jmeter.sh
# Requires: jmeter on PATH, the Spring Boot app + Redis running on localhost:8081
#
# It runs the same test plan 3 times (10, 50, 100 concurrent users) and,
# for each, once against a freshly flushed cache (Trie path) and once
# immediately after (Redis path), producing 6 aggregate reports + 6 HTML
# dashboards you can screenshot for the lab record.

set -e
JMX=autocomplete_test_plan.jmx
OUT=jmeter_results
mkdir -p "$OUT"

run_case () {
  USERS=$1
  MODE=$2   # "cold" or "warm"
  LABEL="${MODE}_${USERS}users"

  if [ "$MODE" = "cold" ]; then
    echo ">> Flushing Redis (forcing cache MISS / Trie path) for $LABEL"
    redis-cli FLUSHALL
  fi

  echo ">> Running $LABEL ..."
  jmeter -n -t "$JMX" \
    -Jusers="$USERS" -Jrampup=5 -Jloops=20 -Jk=5 \
    -Jhost=localhost -Jport=8081 \
    -l "$OUT/${LABEL}.jtl" \
    -e -o "$OUT/${LABEL}_report"
}

for USERS in 10 50 100; do
  run_case "$USERS" cold
  run_case "$USERS" warm
done

echo "Done. Open $OUT/<label>_report/index.html for each HTML dashboard,"
echo "and $OUT/<label>.jtl for the raw sample log."
