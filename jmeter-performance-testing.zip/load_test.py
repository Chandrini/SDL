"""
Load-test harness for the Autocomplete REST API (GET /autocomplete?prefix=..&k=..)

Mimics what a JMeter Thread Group + Aggregate Report would measure:
  - N concurrent "users" (threads) firing requests
  - per-request latency
  - throughput (req/sec)
  - error %
  - min / avg / max / p90 / p95 latency

For each concurrency level we run TWO rounds against the SAME set of
(prefix, k) combinations:
  Round A ("TRIE")  - redis is flushed first, so every request is a cache
                      MISS and is served by the Trie.
  Round B ("REDIS") - the exact same requests are replayed, so every one
                      is now a cache HIT.

This isolates the effect of the Redis cache from the effect of concurrency,
which is what Task/Analysis Q3-Q5 in the lab ask you to explain.
"""

import csv
import statistics as stats
import subprocess
import time
import json
from concurrent.futures import ThreadPoolExecutor, as_completed

import urllib.request
import urllib.parse

BASE_URL = "http://localhost:8081/autocomplete"
PREFIXES_FILE = "/home/claude/perf/prefixes.csv"
K_VALUES = list(range(1, 21))  # 20 distinct k values per prefix -> unique cache keys
CONCURRENCY_LEVELS = [10, 50, 100]
RESULTS_CSV = "/home/claude/perf/results.csv"


def load_prefixes():
    with open(PREFIXES_FILE) as f:
        reader = csv.DictReader(f)
        return [row["prefix"] for row in reader]


def build_requests(prefixes):
    combos = []
    for p in prefixes:
        for k in K_VALUES:
            combos.append((p, k))
    return combos


def flush_redis():
    subprocess.run(["redis-cli", "FLUSHALL"], check=True, capture_output=True)


def hit(prefix, k):
    url = f"{BASE_URL}?{urllib.parse.urlencode({'prefix': prefix, 'k': k})}"
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            body = resp.read()
            ok = resp.status == 200
            source = json.loads(body).get("source", "?")
    except Exception:
        ok = False
        source = "ERROR"
    elapsed_ms = (time.perf_counter() - start) * 1000
    return ok, elapsed_ms, source


def run_round(combos, concurrency, label):
    latencies = []
    errors = 0
    sources = {}
    wall_start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        futures = [pool.submit(hit, p, k) for (p, k) in combos]
        for fut in as_completed(futures):
            ok, ms, source = fut.result()
            latencies.append(ms)
            sources[source] = sources.get(source, 0) + 1
            if not ok:
                errors += 1
    wall_time = time.perf_counter() - wall_start

    latencies.sort()
    n = len(latencies)
    def pct(p):
        idx = min(n - 1, int(round(p / 100 * n)))
        return latencies[idx]

    row = {
        "label": label,
        "concurrency": concurrency,
        "samples": n,
        "errors": errors,
        "error_pct": round(100 * errors / n, 2) if n else 0,
        "avg_ms": round(stats.mean(latencies), 2) if latencies else 0,
        "min_ms": round(min(latencies), 2) if latencies else 0,
        "max_ms": round(max(latencies), 2) if latencies else 0,
        "p90_ms": round(pct(90), 2) if latencies else 0,
        "p95_ms": round(pct(95), 2) if latencies else 0,
        "wall_time_s": round(wall_time, 3),
        "throughput_rps": round(n / wall_time, 2) if wall_time > 0 else 0,
        "sources": sources,
    }
    return row


def main():
    prefixes = load_prefixes()
    combos = build_requests(prefixes)
    print(f"Loaded {len(prefixes)} prefixes -> {len(combos)} unique (prefix,k) requests per round\n")

    results = []
    for c in CONCURRENCY_LEVELS:
        # Round A: force cache MISS -> Trie path
        flush_redis()
        row_trie = run_round(combos, c, "TRIE (cache miss)")
        results.append(row_trie)
        print(row_trie)

        # Round B: same requests, now cached -> Redis path
        row_redis = run_round(combos, c, "REDIS (cache hit)")
        results.append(row_redis)
        print(row_redis)
        print()

    fieldnames = ["label", "concurrency", "samples", "errors", "error_pct",
                  "avg_ms", "min_ms", "max_ms", "p90_ms", "p95_ms",
                  "wall_time_s", "throughput_rps", "sources"]
    with open(RESULTS_CSV, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            r = dict(r)
            r["sources"] = json.dumps(r["sources"])
            writer.writerow(r)

    print(f"Saved results to {RESULTS_CSV}")


if __name__ == "__main__":
    main()
