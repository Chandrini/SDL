# Lab Exercise 7 — JMeter Load Test & Performance Analysis

## 1. Test Setup

- **App under test:** Spring Boot autocomplete service, `GET /autocomplete?prefix=..&k=..`, port 8081
- **Cache:** Redis (key = `autocomplete:<prefix>:<k>`)
- **Dataset:** `search_terms.csv` (28 terms), queried via 15 representative prefixes (`a`, `ap`, `app`, `appl`, `b`, `ba`, `ban`, `bo`, `book`, `c`, `ca`, `car`, `co`, `col`, `com`)
- **Tool:** `autocomplete_test_plan.jmx` (JMeter, parameterized by `-Jusers`, `-Jrampup`, `-Jloops`, `-Jk`), run via `run_jmeter.sh` at three workloads: **10, 50, 100 concurrent users**
- **Method:** for each workload, the same 300 requests (15 prefixes × 20 distinct `k` values, to force unique cache keys) were run twice:
  - **Round A** — Redis flushed first → every request is a cache **miss**, served by the **Trie**
  - **Round B** — same requests replayed → every request is a cache **hit**, served by **Redis**

> Note: JMeter itself can't be installed inside this sandbox (no internet access to Apache's servers), so the numbers below come from an equivalent concurrent-request harness (`load_test.py`) run directly against the live Spring Boot + Redis instance in this environment. The `.jmx` file is unchanged and ready to run for real in your lab — `run_jmeter.sh` will reproduce the same experiment and give you the official HTML dashboard/Aggregate Report to screenshot for your record.

## 2. Results

| Workload | Path | Avg (ms) | Min (ms) | Max (ms) | p90 (ms) | p95 (ms) | Throughput (req/s) | Errors |
|---|---|---|---|---|---|---|---|---|
| 10 users | TRIE (miss) | 45.74 | 9.82 | 415.07 | 54.39 | 75.23 | 210.93 | 0% |
| 10 users | REDIS (hit) | 26.75 | 5.05 | 60.48 | 38.21 | 45.73 | 362.17 | 0% |
| 50 users | TRIE (miss) | 127.36 | 43.68 | 248.43 | 190.46 | 206.58 | 372.84 | 0% |
| 50 users | REDIS (hit) | 91.70 | 21.29 | 303.34 | 146.57 | 175.42 | 514.09 | 0% |
| 100 users | TRIE (miss) | 216.82 | 41.87 | 421.33 | 325.88 | 368.18 | 411.90 | 0% |
| 100 users | REDIS (hit) | 167.54 | 33.16 | 264.18 | 212.70 | 222.24 | 507.84 | 0% |

**Takeaways:**
- At every concurrency level, the Redis-cached path has **~35–42% lower average latency** and **~23–71% higher throughput** than the Trie path.
- Latency rises with concurrency for both paths (Tomcat's fixed worker-thread pool queues requests once concurrent load exceeds it), but the *gap* between Trie and Redis stays consistent — the cache saves the same relative amount of work regardless of load.
- Zero errors across all runs, so the bottleneck at 100 users is queuing/response time, not failures.

## 3. Analysis (per the lab's Analysis section)

**Trie:** stores every search term character-by-character in a shared tree, so all terms with a common prefix share the same path from the root. It gives suggestions in O(length of prefix + number of matches) instead of scanning every term.

**Prefix:** the partial string the user has typed so far (`app`); it's the lookup key that narrows the Trie traversal down to one subtree.

**Redis Cache:** an in-memory key-value store sitting in front of the Trie. Once a `(prefix, k)` pair has been served once, the ranked suggestion list is stored under `autocomplete:<prefix>:<k>` so identical future requests skip the Trie walk entirely.

**Top-K Suggestions:** rather than returning every matching term, the service sorts matches by search frequency and returns only the `k` highest — keeping the response small and the most relevant terms first.

**How the Trie resolves a prefix:** the service walks the Trie one character at a time following the prefix; if any character has no matching child, there are no completions and it returns empty. Otherwise it lands on the node for the last prefix character and does a DFS from there, collecting every node marked "end of word," then sorts those by frequency and takes the first `k`.

**Request flow — prefix IS in Redis:** the controller calls the service, which builds the cache key and does a `GET` on Redis. The cached string is parsed back into a suggestion list and returned immediately, source `"REDIS"` — no Trie traversal happens at all.

**Request flow — prefix NOT in Redis:** the `GET` returns null, so the service falls through to the Trie (`findPrefixNode` → `collectWords` → sort → limit `k`), builds the response, then serializes it and does a Redis `SET` before returning it (source `"TRIE"`), so the next request for the same `(prefix, k)` becomes a cache hit.

**Trie vs linear search:** a linear scan checks every one of the N terms against the prefix on every request — O(N × prefix length) in the worst case, and it gets worse as the dataset grows. The Trie's cost depends only on the prefix length and the number of matches under it, not on how many total terms exist, so it scales far better as the term list grows into the millions (typical for real autocomplete systems). The measured numbers above show the Trie path is already fast (tens of ms), but Redis is faster still because it skips the traversal entirely — the real value of the Trie shows up as the dataset scales past what fits comfortably in a linear scan.

## 4. Files

- `autocomplete_test_plan.jmx` — the JMeter test plan (import into JMeter GUI, or run headless with `run_jmeter.sh`)
- `prefixes.csv` — CSV Data Set used by the plan
- `run_jmeter.sh` — runs all 6 cases (3 workloads × cold/warm) and produces HTML dashboards
- `load_test.py` — the harness used to produce the numbers above (works without JMeter installed)
- `results.csv` — raw aggregate stats from the run
