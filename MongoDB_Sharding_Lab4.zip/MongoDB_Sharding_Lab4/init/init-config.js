// Initialize the config-server replica set. Run once on a fresh volume.
rs.initiate({
  _id: "configRS",
  configsvr: true,
  members: [{ _id: 0, host: "configsvr:27019" }]
});
