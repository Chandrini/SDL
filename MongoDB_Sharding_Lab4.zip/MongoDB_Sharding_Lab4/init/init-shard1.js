// Initialize shard 1 replica set. Run once on a fresh volume.
rs.initiate({
  _id: "shard1RS",
  members: [{ _id: 0, host: "shard1:27018" }]
});
