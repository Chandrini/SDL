// Initialize shard 2 replica set. Run once on a fresh volume.
rs.initiate({
  _id: "shard2RS",
  members: [{ _id: 0, host: "shard2:27017" }]
});
