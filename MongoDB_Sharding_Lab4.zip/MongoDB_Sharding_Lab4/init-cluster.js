// Run through mongos after the config and shard replica sets are PRIMARY.
print("\n--- Register shards ---");
const shardList = db.adminCommand({ listShards: 1 }).shards.map(s => s._id);
if (!shardList.includes("shard1RS")) printjson(sh.addShard("shard1RS/shard1:27018"));
if (!shardList.includes("shard2RS")) printjson(sh.addShard("shard2RS/shard2:27017"));

print("\n--- Enable sharding for College ---");
printjson(sh.enableSharding("College"));
const college = db.getSiblingDB("College");
if (!college.getCollectionNames().includes("Student")) college.createCollection("Student");

print("\n--- Shard Student on RollNo ---");
const collInfo = db.getSiblingDB("config").collections.findOne({ _id: "College.Student" });
if (!collInfo) {
  printjson(sh.shardCollection("College.Student", { RollNo: 1 }));
  // Split the range and move the upper half to shard 2 to make distribution visible in the lab.
  printjson(sh.splitAt("College.Student", { RollNo: 501 }));
  printjson(sh.moveChunk("College.Student", { RollNo: 501 }, "shard2RS"));
} else {
  print("College.Student is already sharded; leaving its current chunk layout unchanged.");
}

print("\n--- Insert sample student records (RollNo 1-1000) ---");
const departments = ["CSE", "IT", "ECE", "EEE", "MECH"];
const docs = [];
for (let i = 1; i <= 1000; i++) {
  docs.push({
    RollNo: i,
    Name: "Student_" + String(i).padStart(4, "0"),
    Department: departments[(i - 1) % departments.length],
    Year: 2 + (i % 2),
    Email: "student" + i + "@college.edu"
  });
}
// Makes the script safe to re-run without duplicate RollNo values.
for (let i = 0; i < docs.length; i += 500) {
  const batch = docs.slice(i, i + 500);
  const ops = batch.map(doc => ({ updateOne: { filter: { RollNo: doc.RollNo }, update: { $set: doc }, upsert: true } }));
  college.Student.bulkWrite(ops, { ordered: false });
}

print("\n--- Query through mongos ---");
print("Student with RollNo 501:");
printjson(college.Student.findOne({ RollNo: 501 }));
print("Total student records: " + college.Student.countDocuments());
print("\n--- Registered shards ---");
printjson(db.adminCommand({ listShards: 1 }));
print("\n--- Sharding status ---");
sh.status();
