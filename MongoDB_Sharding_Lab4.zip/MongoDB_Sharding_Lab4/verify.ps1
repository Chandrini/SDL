$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host "--- Cluster shard list ---" -ForegroundColor Cyan
docker exec mongos mongosh --quiet --port 27016 --eval "db.adminCommand({listShards:1})"
Write-Host "`n--- Sharding status ---" -ForegroundColor Cyan
docker exec mongos mongosh --quiet --port 27016 --eval "sh.status()"
Write-Host "`n--- Student count via mongos ---" -ForegroundColor Cyan
docker exec mongos mongosh --quiet --port 27016 --eval "db.getSiblingDB('College').Student.countDocuments()"
Write-Host "`n--- Documents physically present on shard 1 ---" -ForegroundColor Cyan
docker exec shard1 mongosh --quiet --port 27018 --eval "db.getSiblingDB('College').Student.countDocuments()"
Write-Host "`n--- Documents physically present on shard 2 ---" -ForegroundColor Cyan
docker exec shard2 mongosh --quiet --port 27017 --eval "db.getSiblingDB('College').Student.countDocuments()"
Write-Host "`n--- Example targeted query through mongos ---" -ForegroundColor Cyan
docker exec mongos mongosh --quiet --port 27016 --eval "db.getSiblingDB('College').Student.find({RollNo:501}).toArray()"
