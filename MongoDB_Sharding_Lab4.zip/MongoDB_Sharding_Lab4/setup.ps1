$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Invoke-DockerChecked([string[]]$ArgsList) {
    & docker @ArgsList
    if ($LASTEXITCODE -ne 0) { throw "Docker command failed: docker $($ArgsList -join ' ')" }
}
function Wait-Mongo([string]$Container, [int]$Port) {
    Write-Host "Waiting for $Container on port $Port ..."
    for ($i = 0; $i -lt 60; $i++) {
        & docker exec $Container mongosh --quiet --port $Port --eval "db.adminCommand('ping').ok" *> $null
        if ($LASTEXITCODE -eq 0) { return }
        Start-Sleep -Seconds 2
    }
    throw "Timed out waiting for $Container. Check Docker Desktop and container logs."
}
function Wait-Primary([string]$Container, [int]$Port) {
    Write-Host "Waiting for $Container replica set to elect a primary ..."
    for ($i = 0; $i -lt 60; $i++) {
        $state = & docker exec $Container mongosh --quiet --port $Port --eval "rs.status().myState" 2>$null
        if ($LASTEXITCODE -eq 0 -and (($state -join '').Trim() -eq '1')) { return }
        Start-Sleep -Seconds 2
    }
    throw "Timed out waiting for $Container to become PRIMARY. Check container logs."
}
function Run-Eval([string]$Container, [int]$Port, [string]$Js) {
    & docker exec $Container mongosh --quiet --port $Port --eval $Js
    if ($LASTEXITCODE -ne 0) { throw "MongoDB initialization failed on $Container. See error above." }
}

Write-Host "Starting MongoDB sharded-cluster containers..." -ForegroundColor Cyan
Invoke-DockerChecked @('compose', 'up', '-d')
Wait-Mongo 'configsvr' 27019
Wait-Mongo 'shard1' 27018
Wait-Mongo 'shard2' 27017

# Initialize only when a replica set has not already been initialized.
$cfg = & docker exec configsvr mongosh --quiet --port 27019 --eval "rs.status().ok" 2>$null
if (($cfg -join '').Trim() -ne '1') {
    Run-Eval 'configsvr' 27019 "rs.initiate({_id:'configRS',configsvr:true,members:[{_id:0,host:'configsvr:27019'}]})"
}
$one = & docker exec shard1 mongosh --quiet --port 27018 --eval "rs.status().ok" 2>$null
if (($one -join '').Trim() -ne '1') {
    Run-Eval 'shard1' 27018 "rs.initiate({_id:'shard1RS',members:[{_id:0,host:'shard1:27018'}]})"
}
$two = & docker exec shard2 mongosh --quiet --port 27017 --eval "rs.status().ok" 2>$null
if (($two -join '').Trim() -ne '1') {
    Run-Eval 'shard2' 27017 "rs.initiate({_id:'shard2RS',members:[{_id:0,host:'shard2:27017'}]})"
}
Wait-Primary 'configsvr' 27019
Wait-Primary 'shard1' 27018
Wait-Primary 'shard2' 27017
Wait-Mongo 'mongos' 27016

Write-Host "Applying sharding configuration and inserting 1,000 sample records..." -ForegroundColor Cyan
Invoke-DockerChecked @('cp', (Join-Path $PSScriptRoot 'init-cluster.js'), 'mongos:/tmp/init-cluster.js')
Invoke-DockerChecked @('exec', 'mongos', 'mongosh', '--quiet', '--port', '27016', '/tmp/init-cluster.js')

Write-Host "`nSetup complete! Connect to mongos at localhost:27016." -ForegroundColor Green
Write-Host "To open the MongoDB shell: docker exec -it mongos mongosh --port 27016"
Write-Host "To inspect shard distribution: docker exec -it mongos mongosh --port 27016"
