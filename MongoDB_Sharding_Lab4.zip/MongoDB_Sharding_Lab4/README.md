# System Design Lab — Lab Exercise 4: MongoDB Horizontal Sharding

This project builds a small MongoDB sharded cluster using Docker Compose and MongoDB 7.0.

## Architecture

- `configsvr` — config-server replica set (`configRS`), port 27019
- `shard1` — shard replica set (`shard1RS`), port 27018
- `shard2` — shard replica set (`shard2RS`), port 27017
- `mongos` — query router, port 27016
- Database: `College`
- Collection: `Student`
- Shard key: `{ RollNo: 1 }` (range-based)

Each replica set in this lab has only one member. This demonstrates the sharding architecture but does not provide replica-set redundancy or high availability.

## Requirements

1. Windows 10/11 with Docker Desktop installed and running.
2. Docker Compose v2 (`docker compose` command).
3. Internet connection on first run to pull `mongo:7.0`.
4. Ports 27016–27019 free on the host.

## Run the project (Windows PowerShell)

1. Extract the ZIP to a normal folder.
2. Start Docker Desktop and wait until it says Docker is running.
3. Open PowerShell in the extracted `MongoDB_Sharding_Lab4` folder (or navigate to the extracted folder).
4. Run:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\setup.ps1
   ```

The script starts the four containers, initializes each replica set, waits for primary election, adds both shards, enables sharding for `College`, shards `College.Student` by `RollNo`, splits at RollNo 501, moves the upper range to shard 2, and upserts 1,000 sample student documents. It is designed to be safe to run again with existing data; it does not erase your volumes.

The explicit split and move are included so the lab visibly demonstrates data placement on both shards with this sample dataset. Real production placement is managed according to workload and balancing policy.

## Verify the result

Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\verify.ps1
```

It prints the shard list, sharding status, total records seen through `mongos`, document counts directly on each shard, and an example query.

Open an interactive shell routed through `mongos`:

```powershell
docker exec -it mongos mongosh --port 27016
```

Then try:

```javascript
use College
db.Student.findOne({ RollNo: 501 })
db.Student.find({ RollNo: { $gte: 995 } }).toArray()
db.Student.countDocuments()
sh.status()
db.adminCommand({ listShards: 1 })
```

Always run normal application queries through `mongos` (port 27016), not directly against a shard.

## Stop the cluster

This stops containers but preserves data volumes:

```powershell
docker compose down
```

To completely reset the lab and DELETE its database volumes, run this from the project folder:

```powershell
docker compose down -v
```

Then run `setup.ps1` again. **The `-v` command permanently removes this lab's saved MongoDB data.**

## Troubleshooting

- If Docker commands fail, open Docker Desktop and wait for it to finish starting.
- If a port is already in use, stop the other service or change the matching host-side port mapping in `docker-compose.yml`.
- If a container exits, inspect it with `docker compose logs configsvr`, `docker compose logs shard1`, `docker compose logs shard2`, or `docker compose logs mongos`.
- First startup can take a few minutes while the MongoDB image downloads and replica sets elect their primary members.
- If you previously changed replica-set hostnames or configuration, reset the lab volumes with `docker compose down -v` and run setup again.
