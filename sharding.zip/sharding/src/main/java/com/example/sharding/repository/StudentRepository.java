package com.example.sharding.repository;

import com.example.sharding.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface StudentRepository extends MongoRepository<Student, Integer> {
    List<Student> findByDepartment(String department);
    List<Student> findByRollNoBetween(Integer start, Integer end);
}