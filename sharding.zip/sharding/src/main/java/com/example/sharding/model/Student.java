package com.example.sharding.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Student")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    private Integer rollNo;   // shard key

    private String name;
    private String department;
    private Integer year;
    private Double cgpa;
}