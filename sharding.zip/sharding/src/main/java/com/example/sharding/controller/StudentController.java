package com.example.sharding.controller;
import com.example.sharding.model.Student;

import com.example.sharding.repository.StudentRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentRepository repository;

    public StudentController(StudentRepository repository) {
        this.repository = repository;
    }

    @PostMapping
    public Student addStudent(@RequestBody Student student) {
        return repository.save(student);
    }

    @PostMapping("/bulk/{count}")
    public String addBulk(@PathVariable int count) {
        for (int i = 1; i <= count; i++) {
            Student s = new Student(i, "Student" + i, "CSE", (i % 4) + 1,
                    6.0 + Math.random() * 4);
            repository.save(s);
        }
        return count + " students inserted through mongos across shards.";
    }

    @GetMapping("/{rollNo}")
    public Student getByRollNo(@PathVariable Integer rollNo) {
        return repository.findById(rollNo).orElse(null);
    }

    @GetMapping("/department/{dept}")
    public List<Student> getByDepartment(@PathVariable String dept) {
        return repository.findByDepartment(dept);
    }

    @GetMapping("/range")
    public List<Student> getByRange(@RequestParam int start, @RequestParam int end) {
        return repository.findByRollNoBetween(start, end);
    }

    @GetMapping
    public List<Student> getAll() {
        return repository.findAll();
    }
}
